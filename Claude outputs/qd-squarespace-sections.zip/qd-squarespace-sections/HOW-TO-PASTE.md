# How to paste these sections into Squarespace

Nine sections, written as self-contained HTML + CSS + JS. Verified rendering —
no console errors, layout holds from 390px to 1600px.

**Images are referenced straight from Unsplash URLs**, so there is nothing to
upload and no picker to click through. They load on the live site.

---

## Before you start — one requirement

**Code Blocks need the Core plan or above.** Same gate as Code Injection. On the
free trial the block may save but not render. If the client is subscribing
anyway (the trial ends in 14 days), do that first and this all works. On Basic,
none of it does.

---

## Step 1 — the stylesheet (do this once)

Open **Website → Website Tools → Custom CSS** and paste the whole of
`_shared.css` at the **end** of what is already there. Do not replace the
existing CSS — the earlier design system is still doing the work on the header,
the hero, the services cards and the contact form.

Everything in this file is scoped under `.qd`, so it cannot collide with
Squarespace's own styles or with the existing rules.

Save, and confirm it saved — Squarespace occasionally drops a save silently.
Reload the panel and check the content is still there.

## Step 2 — the sections

For each file, on the Home page:

1. Hover between two sections → **Add Section** → **Blank**
2. Inside it, **Add Block** → **Code**
3. Delete the placeholder contents, paste the file's entire contents
4. Set the section's own padding to zero if Squarespace adds any — each block
   brings its own spacing

Paste them in this order, below the existing hero:

| Order | File | Replaces |
| --- | --- | --- |
| 1 | `01-trustbar.html` | — (new) |
| 2 | `02-about.html` | the template's "Explore" section |
| 3 | — | **keep the native services cards** you already have |
| 4 | `03-mission-stats.html` | — (new) |
| 5 | `04-approach.html` | — (new) |
| 6 | `05-speed-ai.html` | — (new) |
| 7 | `06-testimonials.html` | the template's "Clients" section |
| 8 | `07-partnership.html` | — (new) |
| 9 | `08-faq.html` | — (new) |
| 10 | `09-cta.html` | the template's "Let's Build!" section |

Then delete the leftover Radian sections: Projects heading, Explore, the three
project detail sections, Clients, Let's Build!, About.

## Step 3 — the reveal animation

`09-cta.html` already carries the scroll-reveal script at the bottom, and
`03-mission-stats.html` carries the count-up script. Both are self-guarding, so
they run once no matter how many blocks contain them. If you drop the CTA
section, move the snippet in `00-reveal-snippet.txt` into any other block.

---

## What stays native (do not replace these)

- **The contact form** — it needs Squarespace's server to receive submissions.
  Leave it exactly as it is.
- **The services cards** — already built as a List Section, already written, and
  the client can edit them without touching code.
- **Header and navigation** — Squarespace's own.

---

## Editing these later

Text and images inside the pasted sections are changed by editing the HTML in
the Code Block, not through the visual editor. Images are the `src="..."` URLs —
swap in any other Unsplash URL, or an uploaded Squarespace image URL.

This is the trade that was accepted in choosing the code route: faster to build,
much closer to the original design, but these sections are developer-edited.
The parts the client is most likely to want to change — services, the form —
were deliberately left native.

---

## Swapping in the real client portal

In `07-partnership.html` there is a commented block near the bottom. When the
client supplies their Dubsado or HoneyBook form URL, replace the "Client portal"
card with:

```html
<iframe src="PASTE_URL_HERE"
        style="width:100%;height:760px;border:0;border-radius:1.4rem;background:#fff"
        loading="lazy"></iframe>
```

---

## Still needs the client's decision

Three things in this content are carried over from the Next.js build and are
**not verified fact**:

- The stat figures in `03-mission-stats.html` (18+, 40+, 96%, 24h)
- The three testimonials in `06-testimonials.html` — these were written as
  sample copy, not real client feedback
- Any claim about an AI assistant — I softened the wording in `05-speed-ai.html`
  to "accelerated discovery" since there is no live assistant behind it, but
  check the client is comfortable with how it reads

Do not publish the testimonials as genuine without the client confirming them.
